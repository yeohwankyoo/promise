package com.example.promise;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.util.Log;
import android.widget.Toast;
import java.util.ArrayList;

public class PhoneList implements Runnable {
    private Context mContext;
    private Cursor mCursor;
    final ArrayList<String> item = new ArrayList<String>();
    //String[] result;

    public PhoneList(Context context) {
        mContext = context;
    }

    @Override
    public void run() {
        mCursor = mContext.getContentResolver().query(Phone.CONTENT_URI, null, null, null, null);

        String name;
        String number;
        int i=0;

        if (mCursor.moveToFirst() && mCursor.getCount() > 0) {
            do {
                name = mCursor.getString(mCursor.getColumnIndex(Phone.DISPLAY_NAME));
                number = mCursor.getString(mCursor.getColumnIndex(Phone.NUMBER));

                Log.d("MyContactList", "Name : " + name + " / Number : " + number);
                //item[i] = name.toString();
                item.add(name);
                //Toast.makeText(this,"test = "+item[i],Toast.LENGTH_SHORT).show();
                i++;
            } while(mCursor.moveToNext());
        }

        //result = new String[i];
        //for(int k=0;k<i;k++){
        //result[k] = item[k];
        //}

        mCursor.close();
    }


}