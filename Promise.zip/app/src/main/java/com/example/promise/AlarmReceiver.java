package com.example.promise;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.IBinder;
import android.os.Vibrator;
import android.text.Editable;
import android.util.Log;
import android.widget.Toast;
import android.media.AudioManager;
/**
 * Created by 광선 on 2016-06-08.
 */
public class AlarmReceiver extends BroadcastReceiver {
/*
    //----------------- gps ---------------//
    SharedPreferences isLate;
    SharedPreferences.Editor editor;

    private String mExpectedAction;
    private Intent mLastReceivedIntent;

    public AlarmReceiver(String expectedAction) {
        mExpectedAction = expectedAction;
        mLastReceivedIntent = null;
    }

    public IntentFilter getFilter() {
        IntentFilter filter = new IntentFilter(mExpectedAction);
        return filter;
    }
    //----------------- gps --------------//
*/
    /**
     * 받았을 때 호출되는 메소드
     *
     * @param context
     * @param intent
     */

    PopUp AActivity = (PopUp) this.AActivity;

    @Override
    public void onReceive(Context context, Intent intent) {

       /* if(intent.getStringExtra("signal").equals("-1")) {
            isLate = context.getSharedPreferences("islate", Context.MODE_PRIVATE);
            editor = isLate.edit();
            editor.putString("key","-1");
            editor.commit();
        }*/

        Intent late = new Intent(context, LateScreen.class);// notification을 눌렀을 때 로딩 화면이 뜨도록 설정
        PendingIntent pit = PendingIntent.getActivity(context, 0, late, 0);
        try {
            pit.send();
        } catch (PendingIntent.CanceledException e) {
            e.printStackTrace();
        }

        //Vibrator vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);  // <- or Context.VIBRATE_SERVICE)
        //vibrator.vibrate(5000);// 반복 횟수

        AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);// 강제로 소리모드로 바꿔줌

        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        Ringtone r = RingtoneManager.getRingtone(context, notification);
        r.play();

        //------------------------------------ Notification -----------------------------------//
        //NotificationManager 안드로이드 상태바에 메세지를 던지기위한 서비스 불러오고
        NotificationManager notificationmanager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, new Intent(context, LoadingActivity.class), PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder builder = new Notification.Builder(context);
        builder.setSmallIcon(R.drawable.icon2).setTicker("HETT").setWhen(System.currentTimeMillis())
                .setNumber(1).setContentTitle("약속해줘").setContentText("약속 시간을 어겼다네~ ")
                .setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE | Notification.DEFAULT_LIGHTS).setContentIntent(pendingIntent).setAutoCancel(true);

        notificationmanager.notify(1, builder.build());
        //---------------------------------------------------------------------------------------//
    }
/*
    public Intent getLastReceivedIntent() {
        return mLastReceivedIntent;
    }

    public void clearReceivedIntents() {
        mLastReceivedIntent = null;
    }
*/
}
